print `Hello, world!`
exit
