!   editor_server.as
!   File server for the scripted editor.
!   Usage: allspeak tests/editor_server.as
!
!   Routes (all paths absolute on the local filesystem):
!     GET  /read<path>  →  returns file contents
!     POST /write<path> →  writes request body to file; returns OK
!     GET  /list<path>  →  returns JSON array of filenames in directory

    script EditorServer

    use server

    variable FullPath
    variable FilePath
    variable Content
    variable FileList
    variable Port
    server Files

    set Port to 17348
    start Files on port Port

    print `Editor file server running on port ` cat Port
    print `Press Ctrl+C to stop`

    on Files request
    begin
        set FullPath to Files path

        if FullPath starts with `/read`
        begin
            put FullPath into FilePath
            replace `/read` with `` in FilePath
            load Content from FilePath
            return Content to Files
        end
        else if FullPath starts with `/write`
        begin
            put FullPath into FilePath
            replace `/write` with `` in FilePath
            get Content from Files
            save Content to FilePath
            return `OK` to Files
        end
        else if FullPath starts with `/list`
        begin
            put FullPath into FilePath
            replace `/list` with `` in FilePath
            set FileList to files in FilePath
            return FileList to Files
        end
        else
        begin
            return `Unknown command` to Files with status 404
        end
    end
